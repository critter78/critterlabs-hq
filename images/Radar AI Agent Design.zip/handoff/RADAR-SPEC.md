# RADAR — Chat Agent Spec

**Product:** AI agent that helps prospects scope & launch a custom dashboard build with CritterLabs HQ.
**Surface:** Floating launcher + chat window, embedded on `hq.critterlabs.io`.
**Files in this handoff:**
- `radar-widget.html` — drop-in reference implementation (vanilla HTML/CSS/JS, no build step).
- `Radar.dc.html` — full design canvas (all launcher concepts + 3 chat states) for visual reference.

---

## 1. Identity & voice
- **Name:** Radar. **Tagline:** *“your eyes on the data.”*
- **Persona:** the studio insider who can already see your whole picture. Sharp, warm, plain-spoken. Light, sparing play on the radar/“on my radar / see-everything” theme — never gimmicky.
- **Mascot:** *The Radar Critter* — a small character whose face is a radar scope: two expressive eyes (with pupils + catchlight), amber wireframe glasses, a friendly smile, a sensor antenna with an amber blip, and a green radar sweep rotating behind the face as his “mind.”

## 2. Color tokens
| Token | Hex | Use |
|---|---|---|
| `--rad-green` | `#3DDC84` | identity, online status, blips, affordances |
| `--rad-amber` | `#F5B53F` | antenna, glasses, highlights, alert badge |
| `--rad-blue`  | `#3B74FF` | primary CTA buttons (matches site) |
| `--rad-bg`    | `#0B0F16` | chat panel background |
| `--rad-header`| `#0E1420` | header gradient top |
| `--rad-input` | `#0C1119` | input bar |
| `--rad-border`| `#1D2532` | panel border |
| `--rad-divider`|`#161D29` | internal dividers |
| bot bubble | bg `#121A26` / border `#1F2937` / text `#D7DEEA` | Radar messages |
| user bubble | bg `#16263F` / border `#24487A` / text `#DCE7F7` | user messages |
| text / muted / faint | `#EEF2F8` / `#7F8B9E` / `#5A6575` | type hierarchy |

All tokens live in `:root` in `radar-widget.html` — re-theme in one place.

## 3. Type
- **UI:** `JetBrains Mono` (400–800). Mono is the whole interface voice — labels are UPPERCASE with `.1–.22em` letter-spacing.
- **Tagline accent:** `Caveat` (handwritten), used *only* for “your eyes on the data” — a small brand nod, nowhere else.

## 4. Launcher
- Size **76px**, rounded **24px**, fixed **24px** from bottom-right (`12px` on mobile).
- Dark green-tinted radial fill, 1px `#1F3A2A` border, soft green glow pulse (`softpulseG`, 3.4s).
- Hover: lift 2px + brighter glow. Active: scale 0.97.
- **Alert badge:** amber circle, top-right, shows unread count; hidden while the chat is open.
- Contains the full Radar Critter face (60px). Min hit target met.

## 5. Chat window
- **380 × 600px**, rounded 20px, anchored above the launcher. Mobile: `100vw − 24px` wide, `min(72vh, 600px)` tall.
- **Header:** 38px Critter avatar · `RADAR` + Caveat tagline · green dot + `ONLINE · HQ BUILD CO-PILOT` · minimize + close.
- **Body:** subtle 26px grid; `TODAY` divider; message rows. Radar bubbles (left, avatar, asymmetric corner `4px 14px 14px 14px`); user bubbles (right, blue, `14px 14px 4px 14px`). Continuation bubbles drop the avatar (26px spacer) and round all corners.
- **Quick-reply chips:** green outline chips; the primary action (`Book a discovery call →`) is a blue chip.
- **Input:** mono placeholder “Message Radar…”, blue 34px send button (`↑`).

## 6. States included
1. **First open** — greeting (2 messages) + 4 suggested chips. *(renders live)*
2. **Scoping a build** — user context → Radar reply → inline **package card** (PRO, price, bullets, blue CTA) → user follow-up → **typing** indicator. *(`<template id="radar-state-scoping">`)*
3. **Booking the call** — Radar reply → inline **booking card** with selectable time slots + “No commitment · no dollar down.” *(`<template id="radar-state-booking">`)*

## 7. Animations (timings)
- `radarspin` 3.4s linear — sweep behind the face.
- `blink` 4.5s — eyes (scaleY pinch at 95%).
- `antbob` 2.4s — antenna bob; `blip` 1.6–2.3s — antenna/blip opacity.
- `softpulseG` 3.4s — launcher glow.
- `typing` 1.3s (3 dots, staggered .2s).
- Respects `prefers-reduced-motion` (animations disabled).

## 8. Behavior / wiring (search `TODO:` in the file)
- Launcher click toggles `.is-open` on the panel + `.open` on the widget (badge hide, glow stop). Esc closes.
- **Chips:** `data-q` holds the question text — route to your backend or open the booking flow.
- **Input submit:** forward the text, then stream Radar’s reply into `.radar-body`.
- **Render a state:** `body.appendChild(document.getElementById('radar-state-booking').content.cloneNode(true))`.
- Booking CTA currently links to `hq.critterlabs.io/contact.html` — swap for your scheduler if desired.

## 9. Accessibility
- Launcher is a real `<button>` with `aria-expanded`; panel is `role="dialog"` with a label.
- Hit targets ≥ 34px; close/minimize are buttons. Color contrast meets AA for body text on the dark panel.

## 10. Notes for implementation
- The Critter face is a self-contained set of `.rc-*` classes — copy as one unit; it scales by setting the face `width/height` and the inline child sizes.
- Remove the `.preview-note` block and the `body{}` backdrop rule when embedding (they’re preview-only).
- No external JS dependencies. Only external assets: the two Google Fonts.
